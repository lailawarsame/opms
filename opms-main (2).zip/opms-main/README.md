A simple HTML/JS/CSS starter template# opms
